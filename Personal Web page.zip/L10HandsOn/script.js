$(document).ready(function() {
    $("#nav").hover(function() {
        $(this).css("background-color" , "red" );    
    }, function(){
        $(this).css("background-color" , "blue" );
    });
});

$(document).ready(function() {
    $("#header").hover(function() {
        $(this).css("background-color" , "silver" );   
    }, function(){
        $(this).css("background-color" , "yellow" );
    });
});

let gitHubRequest = new XMLHttpRequest();
gitHubRequest.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
        let gitObject = JSON.parse(this.responseText);
        document.getElementById("gitHub").innerHTML = gitObject.hub;
    }
};
gitHubRequest.open("GET" , "https://api.github.com/users" , true);
gitHubRequest.send();